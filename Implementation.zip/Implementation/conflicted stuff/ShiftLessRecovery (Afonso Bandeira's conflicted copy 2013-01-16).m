function ShiftLessRecovery

clf

L = 5;
sigma = 1;
Nval = 8*[1:20];
Nmethods = 4;  %CHANGE!!!
Nruns = 5;

NvalNum = length(Nval);
resultsE = zeros(NvalNum,Nmethods);
times = zeros(NvalNum,Nmethods);


for run=1:Nruns
for Ncounter=1:NvalNum
        N = Nval(Ncounter);
    
    x = random('normal',0,1,L,1);  %each component with size O(1);

    %measurements

    Y = zeros(L,N);

    trueShifts = zeros(N,1);
    
    for k=1:N
        shift = random('unid',L);
        trueShifts(k) = shift;
        Y(:,k) = circshift(x,shift) + sigma*random('normal',0,1,L,1);
    end


    %just pick the first one!
        method = 1;
        
        tic
        xest = pickfirst(Y,sigma);
        error = distshiftless(x,xest);
        resultsE(Ncounter,method) = resultsE(Ncounter,method) + error;
        times(Ncounter,method) = times(Ncounter,method) + toc;
        
    % SDP MLE Synch recovering just shifts
        method = 2;
        
        tic
        %xest = SDPugJustPhase(Y, sigma);
        xest = pickfirst(Y,sigma);
        error = distshiftless(x,xest);
        resultsE(Ncounter,method) = resultsE(Ncounter,method) + error;
        times(Ncounter,method) = times(Ncounter,method) + toc;
        
    %do spectral angular synchornization for the shifts
        method = 3;
        
        tic
        xest = angsynchshiftspec(Y,sigma);
        error = distshiftless(x,xest);
        resultsE(Ncounter,method) = resultsE(Ncounter,method) + error;
        times(Ncounter,method) = times(Ncounter,method) + toc;
   
    % SDP MLE Synch recovering signal too
        method = 4;
        
        tic
        %xest = SDPforMLEshiftandsignal(Y,sigma);
        xest = pickfirst(Y,sigma);
        error = distshiftless(x,xest);
        resultsE(Ncounter,method) = resultsE(Ncounter,method) + error;
        times(Ncounter,method) = times(Ncounter,method) + toc;
    
    
end
end



resultsE = resultsE/Nruns;
times = times/Nruns;


figure(73)

subplot(1,2,1)
hold on
%method 1
    p1 = resultsE(:,1);
    plot(Nval,p1,'b')
%method 2
    p1 = resultsE(:,2);
    plot(Nval,p1,'g')
%method 3
    p1 = resultsE(:,3);
    plot(Nval,p1,'r')
%method 4
    p1 = resultsE(:,4);
    plot(Nval,p1,'k')
title('error varying with N')


subplot(1,2,2)
hold on
%method 1
    p1 = times(:,1);
    plot(Nval,p1,'b')
%method 2
    p1 = times(:,2);
    plot(Nval,p1,'g')
%method 3
    p1 = times(:,3);
    plot(Nval,p1,'r')
%method 3
    p1 = times(:,4);
    plot(Nval,p1,'k')
title('time varying with N')


%disp('little test')
%Origx = x
%Corrx = PowerSpectrumCorrection(x,Y,sigma)



end